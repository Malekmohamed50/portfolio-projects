import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'note.dart';

class ArchiveScreen extends StatefulWidget {
  const ArchiveScreen({Key? key}) : super(key: key);

  @override
  _ArchiveScreenState createState() => _ArchiveScreenState();
}

class _ArchiveScreenState extends State<ArchiveScreen> {
  List<Note> archivedNotes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadArchivedNotes();
  }

  Future<void> _loadArchivedNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final archivedData = prefs.getStringList('archivedNotes') ?? [];
    setState(() {
      archivedNotes = archivedData.map((noteData) => Note.fromJson(noteData)).toList();
      _isLoading = false;
    });
  }

  Future<void> _saveArchivedNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final archivedData = archivedNotes.map((note) => note.toJson()).toList();
    await prefs.setStringList('archivedNotes', archivedData);
  }

  Future<void> _moveToTrash(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    final trashData = prefs.getStringList('trashNotes') ?? [];
    trashData.add(note.toJson());
    await prefs.setStringList('trashNotes', trashData);
  }

  Future<void> _removeFromTrash(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    final trashData = prefs.getStringList('trashNotes') ?? [];
    trashData.remove(note.toJson());
    await prefs.setStringList('trashNotes', trashData);
  }

  /// Unarchive a note and return it to the previous screen.
  void _unarchiveNote(int index) async {
    final noteToUnarchive = archivedNotes[index];
    setState(() {
      archivedNotes.removeAt(index);
    });
    await _saveArchivedNotes();
    Navigator.pop(context, noteToUnarchive);
  }

  void _deleteArchivedNote(int index) async {
    final noteToDelete = archivedNotes[index];
    setState(() {
      archivedNotes.removeAt(index);
    });
    await _saveArchivedNotes();
    await _moveToTrash(noteToDelete);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Note moved to Trash'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () async {
            setState(() {
              archivedNotes.insert(index, noteToDelete);
            });
            await _saveArchivedNotes();
            await _removeFromTrash(noteToDelete);
          },
        ),
      ),
    );
  }

  Future<void> _confirmUnarchive(int index) async {
    bool confirm = await _showConfirmationDialog(
      title: "Unarchive Note",
      message: "Are you sure you want to unarchive this note?",
    );
    if (confirm) _unarchiveNote(index);
  }

  Future<void> _confirmDelete(int index) async {
    bool confirm = await _showConfirmationDialog(
      title: "Delete Note",
      message: "Are you sure you want to delete this note? It will be moved to Trash.",
    );
    if (confirm) _deleteArchivedNote(index);
  }

  Future<bool> _showConfirmationDialog({
    required String title,
    required String message,
  }) async {
    return await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: Text(title, style: const TextStyle(color: Colors.white)),
          content: Text(
            message,
            style: const TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text(
                "Cancel",
                style: TextStyle(color: Colors.blue),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text(
                "Confirm",
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    ) ??
        false;
  }

  Future<void> _refresh() async {
    await _loadArchivedNotes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Archived Notes"),
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: _refresh,
        color: Colors.white,
        child: archivedNotes.isEmpty
            ? ListView(
          children: const [
            SizedBox(height: 200),
            Center(
              child: Text(
                "No Archived Notes Found",
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                ),
              ),
            ),
          ],
        )
            : ListView.builder(
          padding: const EdgeInsets.all(8.0),
          itemCount: archivedNotes.length,
          itemBuilder: (context, index) {
            final note = archivedNotes[index];
            // Truncate title to 25 characters and content to 58 characters.
            final truncatedTitle = note.title.length > 25
                ? note.title.substring(0, 25) + "..."
                : note.title;
            final truncatedContent = note.content.length > 58
                ? note.content.substring(0, 58) + "..."
                : note.content;
            return Card(
              color: Colors.grey[850],
              margin: const EdgeInsets.symmetric(vertical: 10),
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      truncatedTitle,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      truncatedContent,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ElevatedButton.icon(
                          icon: const Icon(Icons.unarchive),
                          label: const Text("Unarchive"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () => _confirmUnarchive(index),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.delete_forever),
                          label: const Text("Delete"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () => _confirmDelete(index),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
