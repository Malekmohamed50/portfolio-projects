import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'note.dart';

class AddEditNoteScreen extends StatefulWidget {
  final Note note;
  const AddEditNoteScreen({Key? key, required this.note}) : super(key: key);

  @override
  _AddEditNoteScreenState createState() => _AddEditNoteScreenState();
}

class _AddEditNoteScreenState extends State<AddEditNoteScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _contentController;

  // Formatting states for title
  bool _isTitleBold = false;
  bool _isTitleItalic = false;

  // Formatting states for content
  bool _isContentBold = false;
  bool _isContentItalic = false;
  bool _isContentUnderline = false;

  // Pin state for the note
  bool _isPinned = false;

  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.note.title);
    _contentController = TextEditingController(text: widget.note.content);
    _isPinned = widget.note.isPinned;

    // Initialize formatting from the note model
    _isTitleBold = widget.note.isTitleBold;
    _isTitleItalic = widget.note.isTitleItalic;
    _isContentBold = widget.note.isContentBold;
    _isContentItalic = widget.note.isContentItalic;
    _isContentUnderline = widget.note.isContentUnderline;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<bool> _onBackPressed() async {
    if (_titleController.text.isNotEmpty || _contentController.text.isNotEmpty) {
      final shouldSave = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Unsaved Changes'),
          content: const Text(
            'You have unsaved changes. Do you want to save them?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Discard'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Save'),
            ),
          ],
        ),
      );
      if (shouldSave ?? false) {
        _saveNote();
        return false;
      }
    }
    return true;
  }

  void _saveNote() {
    final title = _titleController.text.trim();
    final content = _contentController.text.trim();

    if (title.isEmpty || content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title and Content cannot be empty')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    // Create updated note including formatting states.
    final updatedNote = Note(
      title: title,
      content: content,
      isPinned: _isPinned,
      isFavorite: widget.note.isFavorite,
      lastModified: DateTime.now(),
      // New formatting properties:
      isTitleBold: _isTitleBold,
      isTitleItalic: _isTitleItalic,
      isContentBold: _isContentBold,
      isContentItalic: _isContentItalic,
      isContentUnderline: _isContentUnderline,
      // Preserve archived and timestamp values:
      archived: widget.note.archived,
      timestamp: widget.note.timestamp,
    );

    Future.delayed(const Duration(seconds: 1), () {
      Navigator.pop(context, updatedNote.toJson());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Note Saved Successfully')),
      );
      setState(() {
        _isSaving = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isNewNote = widget.note.title.isEmpty && widget.note.content.isEmpty;
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          title: Text(isNewNote ? "New Note" : "Edit Note"),
          backgroundColor: Colors.teal,
          actions: [
            // Pin/Unpin Note Button
            IconButton(
              icon: Icon(_isPinned ? Icons.push_pin : Icons.push_pin_outlined),
              onPressed: () {
                setState(() {
                  _isPinned = !_isPinned;
                });
              },
              tooltip: 'Pin/Unpin Note',
            ),
            IconButton(
              icon: _isSaving
                  ? const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              )
                  : const Icon(Icons.save),
              onPressed: _isSaving ? null : _saveNote,
              tooltip: 'Save Note',
            ),
          ],
        ),
        backgroundColor: Colors.grey[900],
        body: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title TextField
                TextField(
                  controller: _titleController,
                  autofocus: isNewNote,
                  style: TextStyle(
                    fontSize: 24,
                    fontFamily: 'Roboto',
                    fontWeight: _isTitleBold ? FontWeight.bold : FontWeight.normal,
                    fontStyle: _isTitleItalic ? FontStyle.italic : FontStyle.normal,
                    color: Colors.white,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Title',
                    hintStyle: const TextStyle(color: Colors.white54),
                    filled: true,
                    fillColor: Colors.grey[850],
                    border: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.white24),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.teal,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                // Title formatting toolbar (Bold & Italic)
                Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.format_bold,
                        color: _isTitleBold ? Colors.teal : Colors.white54,
                      ),
                      onPressed: () {
                        setState(() {
                          _isTitleBold = !_isTitleBold;
                        });
                      },
                      tooltip: 'Toggle Bold for Title',
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.format_italic,
                        color: _isTitleItalic ? Colors.teal : Colors.white54,
                      ),
                      onPressed: () {
                        setState(() {
                          _isTitleItalic = !_isTitleItalic;
                        });
                      },
                      tooltip: 'Toggle Italic for Title',
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Divider(color: Colors.white24, thickness: 1),
                const SizedBox(height: 8),
                // Content formatting toolbar (Bold, Italic, Underline)
                Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.format_bold,
                        color: _isContentBold ? Colors.teal : Colors.white54,
                      ),
                      onPressed: () {
                        setState(() {
                          _isContentBold = !_isContentBold;
                        });
                      },
                      tooltip: 'Toggle Bold for Content',
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.format_italic,
                        color: _isContentItalic ? Colors.teal : Colors.white54,
                      ),
                      onPressed: () {
                        setState(() {
                          _isContentItalic = !_isContentItalic;
                        });
                      },
                      tooltip: 'Toggle Italic for Content',
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.format_underlined,
                        color: _isContentUnderline ? Colors.teal : Colors.white54,
                      ),
                      onPressed: () {
                        setState(() {
                          _isContentUnderline = !_isContentUnderline;
                        });
                      },
                      tooltip: 'Toggle Underline for Content',
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Expanded content TextField
                Expanded(
                  child: TextField(
                    controller: _contentController,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: _isContentBold ? FontWeight.bold : FontWeight.normal,
                      fontStyle: _isContentItalic ? FontStyle.italic : FontStyle.normal,
                      decoration: _isContentUnderline
                          ? TextDecoration.underline
                          : TextDecoration.none,
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Type your note...',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: Colors.grey[850],
                      border: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white24),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                          color: Colors.teal,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
