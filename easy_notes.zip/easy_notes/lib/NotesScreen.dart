import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'AddEditNoteScreen.dart';
import 'ArchiveScreen.dart';
import 'EditProfileScreen.dart';
import 'SearchScreen.dart';
import 'SettingScreen.dart';
import 'TrashScreen.dart';
import 'note.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({Key? key}) : super(key: key);

  @override
  _NotesScreenState createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  List<Note> notes = [];
  String username = '';
  String profilePicturePath = '';
  String selectedSegment = 'all'; // 'all' or 'favorites'
  bool _isGridMode = false; // Toggle between grid and list mode

  // Variables to hold a recently deleted note for undo.
  Note? _recentlyDeletedNote;
  int? _recentlyDeletedIndex;

  @override
  void initState() {
    super.initState();
    _loadNotes();
    _loadUsername();
    _loadProfilePicture();
  }

  Future<void> _loadUsername() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      username = prefs.getString('username') ?? 'User';
    });
  }

  Future<void> _loadProfilePicture() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      profilePicturePath = prefs.getString('profilePicture') ?? '';
    });
  }

  Future<void> _loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final notesData = prefs.getStringList('notes') ?? [];
    setState(() {
      notes = notesData
          .map((noteData) {
        try {
          return Note.fromJson(noteData);
        } catch (e) {
          debugPrint('Error decoding note: $e');
          return null;
        }
      })
          .whereType<Note>()
          .toList();
    });
  }

  Future<void> _saveNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final notesData = notes.map((note) => note.toJson()).toList();
    await prefs.setStringList('notes', notesData);
  }

  void _addNote() async {
    final newNoteJson = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => AddEditNoteScreen(note: Note(title: '', content: '')),
      ),
    );
    if (newNoteJson != null) {
      setState(() {
        notes.add(Note.fromJson(newNoteJson));
      });
      _saveNotes();
    }
  }

  void _editNote(int index) async {
    final editedNoteJson = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => AddEditNoteScreen(note: notes[index])),
    );
    if (editedNoteJson != null) {
      setState(() {
        notes[index] = Note.fromJson(editedNoteJson);
      });
      _saveNotes();
    }
  }

  Future<void> _moveNoteToTrash(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    final trashNotes = prefs.getStringList('trashNotes') ?? [];
    trashNotes.add(note.toJson());
    await prefs.setStringList('trashNotes', trashNotes);
  }

  Future<void> _removeNoteFromTrash(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    final trashNotes = prefs.getStringList('trashNotes') ?? [];
    trashNotes.remove(note.toJson());
    await prefs.setStringList('trashNotes', trashNotes);
  }

  void _deleteNote(int index) {
    // Save note for potential undo.
    _recentlyDeletedNote = notes[index];
    _recentlyDeletedIndex = index;
    final noteToDelete = notes[index];

    setState(() {
      notes.removeAt(index);
    });
    _saveNotes();
    _moveNoteToTrash(noteToDelete);

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Note moved to Trash'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            if (_recentlyDeletedNote != null && _recentlyDeletedIndex != null) {
              setState(() {
                notes.insert(_recentlyDeletedIndex!, _recentlyDeletedNote!);
              });
              _saveNotes();
              _removeNoteFromTrash(_recentlyDeletedNote!);
            }
          },
        ),
      ),
    );
  }

  void _toggleFavorite(int index) {
    setState(() {
      notes[index].isFavorite = !notes[index].isFavorite;
    });
    _saveNotes();
  }

  void _archiveNote(int index) async {
    final noteToArchive = notes[index];
    setState(() {
      notes.removeAt(index);
    });
    _saveNotes();

    final prefs = await SharedPreferences.getInstance();
    final archivedNotes = prefs.getStringList('archivedNotes') ?? [];
    archivedNotes.add(noteToArchive.toJson());
    await prefs.setStringList('archivedNotes', archivedNotes);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Note archived')));
  }

  void _searchNotes() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SearchScreen(notes: notes)),
    );
  }

  void _archivePressed() async {
    final unarchivedNote = await Navigator.push<Note>(
      context,
      MaterialPageRoute(builder: (_) => const ArchiveScreen()),
    );
    if (unarchivedNote != null) {
      setState(() {
        notes.add(unarchivedNote);
      });
      _saveNotes();
    }
  }

  String formatDateTime(DateTime dateTime) {
    return DateFormat('MM/dd/yyyy hh:mm a').format(dateTime);
  }

  /// Widget for list mode (kept for consistency)
  Widget _buildListNoteItem(Note note, int originalIndex) {
    final previewTitle = note.title.length > 25
        ? note.title.substring(0, 25) + '...'
        : note.title;
    final previewText = note.content.length > 58
        ? note.content.substring(0, 58) + '...'
        : note.content;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: GestureDetector(
        onTap: () => _editNote(originalIndex),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.grey[850]!,
                Colors.grey[900]!,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ListTile(
            contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            title: Text(
              previewTitle,
              style: TextStyle(
                fontWeight:
                note.isTitleBold ? FontWeight.bold : FontWeight.normal,
                fontStyle:
                note.isTitleItalic ? FontStyle.italic : FontStyle.normal,
                fontSize: 18,
                color: Colors.white,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text(
                    previewText,
                    style: TextStyle(
                      fontWeight: note.isContentBold
                          ? FontWeight.bold
                          : FontWeight.normal,
                      fontStyle: note.isContentItalic
                          ? FontStyle.italic
                          : FontStyle.normal,
                      decoration: note.isContentUnderline
                          ? TextDecoration.underline
                          : TextDecoration.none,
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Last Modified: ${formatDateTime(note.lastModified)}",
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            leading: IconButton(
              icon: note.isFavorite
                  ? const Icon(
                Icons.favorite,
                color: Colors.red,
              )
                  : const Icon(
                Icons.favorite_border,
                color: Colors.grey,
              ),
              onPressed: () => _toggleFavorite(originalIndex),
              tooltip: "Mark as Favorite",
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (note.isPinned)
                  const Padding(
                    padding: EdgeInsets.only(right: 8.0),
                    child: Icon(
                      Icons.push_pin,
                      color: Colors.yellow,
                    ),
                  ),
                IconButton(
                  icon: const Icon(
                    Icons.archive,
                    color: Colors.white,
                  ),
                  onPressed: () => _archiveNote(originalIndex),
                  tooltip: "Archive Note",
                ),
                IconButton(
                  icon: const Icon(
                    Icons.delete,
                    color: Colors.redAccent,
                  ),
                  onPressed: () => _deleteNote(originalIndex),
                  tooltip: "Delete Note",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Improved widget for grid mode with a refined layout.
  Widget _buildGridNoteItem(Note note, int originalIndex) {
    final previewTitle = note.title.length > 25
        ? note.title.substring(0, 25) + '...'
        : note.title;
    final previewText = note.content.length > 60
        ? note.content.substring(0, 60) + '...'
        : note.content;
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _editNote(originalIndex),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.grey[850]!,
                  Colors.grey[900]!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(2, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Top section: title and preview text.
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            previewTitle,
                            style: TextStyle(
                              fontWeight: note.isTitleBold
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              fontStyle: note.isTitleItalic
                                  ? FontStyle.italic
                                  : FontStyle.normal,
                              fontSize: 16,
                              color: Colors.white,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        IconButton(
                          icon: note.isFavorite
                              ? const Icon(
                            Icons.favorite,
                            color: Colors.redAccent,
                            size: 18,
                          )
                              : const Icon(
                            Icons.favorite_border,
                            color: Colors.white,
                            size: 18,
                          ),
                          onPressed: () => _toggleFavorite(originalIndex),
                          tooltip: "Mark as Favorite",
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      previewText,
                      style: TextStyle(
                        fontWeight: note.isContentBold
                            ? FontWeight.bold
                            : FontWeight.normal,
                        fontStyle: note.isContentItalic
                            ? FontStyle.italic
                            : FontStyle.normal,
                        decoration: note.isContentUnderline
                            ? TextDecoration.underline
                            : TextDecoration.none,
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                // Bottom section: last modified date and action icons.
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Modified: ${formatDateTime(note.lastModified)}",
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.white54,
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.archive,
                            color: Colors.white,
                            size: 18,
                          ),
                          onPressed: () => _archiveNote(originalIndex),
                          tooltip: "Archive Note",
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.delete,
                            color: Colors.redAccent,
                            size: 18,
                          ),
                          onPressed: () => _deleteNote(originalIndex),
                          tooltip: "Delete Note",
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Filter notes based on the selected segment.
    final filteredNotes = selectedSegment == 'favorites'
        ? notes.where((note) => note.isFavorite).toList()
        : List.from(notes);

    // Sort notes so that pinned notes appear at the top.
    filteredNotes.sort((a, b) {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return 0;
    });

    final displayedNotes = filteredNotes;

    return Scaffold(
      backgroundColor: Colors.black,
      endDrawer: Drawer(
        child: Container(
          color: Colors.grey[900],
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.blueGrey.shade700,
                      Colors.blueGrey.shade900,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.grey[300],
                      backgroundImage: profilePicturePath.isNotEmpty
                          ? FileImage(File(profilePicturePath))
                          : null,
                      child: profilePicturePath.isEmpty
                          ? const Icon(
                        Icons.person,
                        color: Colors.grey,
                        size: 32,
                      )
                          : null,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      username,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    TextButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const EditProfileScreen(),
                          ),
                        ).then((updatedUsername) {
                          if (updatedUsername != null) {
                            setState(() {
                              username = updatedUsername;
                            });
                          }
                          _loadProfilePicture();
                        });
                      },
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.white70,
                        size: 16,
                      ),
                      label: const Text(
                        'Edit Profile',
                        style: TextStyle(color: Colors.white70),
                      ),
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(50, 30),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ),
                  ],
                ),
              ),
              _buildDrawerItem(
                icon: Icons.workspace_premium,
                title: 'Premium',
                onTap: () {
                  Navigator.pop(context);
                  _showComingSoonDialog(context);
                },
              ),
              _buildDrawerItem(
                icon: Icons.backup,
                title: 'Backup/Restore',
                onTap: () {
                  Navigator.pop(context);
                  _showComingSoonDialog(context);
                },
              ),
              _buildDrawerItem(
                icon: Icons.archive,
                title: 'Archive',
                onTap: () {
                  Navigator.pop(context);
                  _archivePressed();
                },
              ),
              _buildDrawerItem(
                icon: Icons.delete_outline,
                title: 'Trash',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const TrashScreen()),
                  ).then((_) {
                    _loadNotes();
                  });
                },
              ),
              _buildDrawerItem(
                icon: Icons.settings,
                title: 'Settings',
                subtitle: 'Available now!',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  );
                },
              ),
              _buildDrawerItem(
                icon: Icons.star_rate,
                title: 'Rate App',
                onTap: () {
                  Navigator.pop(context);
                  _showComingSoonDialog(context);
                },
              ),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Text(
                "Welcome, $username!",
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 4),
              Container(height: 2, width: 100, color: Colors.white70),
              const SizedBox(height: 2),
              const Row(
                children: [
                  Text(
                    "My Notes",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(Icons.event_note_rounded, color: Colors.white),
                ],
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: _searchNotes,
            tooltip: "Search Notes",
          ),
          // Toggle button to switch between grid and list views.
          IconButton(
            icon: Icon(
              _isGridMode ? Icons.list : Icons.grid_view,
              color: Colors.white,
            ),
            onPressed: () {
              setState(() {
                _isGridMode = !_isGridMode;
              });
            },
            tooltip: _isGridMode ? "Switch to List Mode" : "Switch to Grid Mode",
          ),
          Builder(
            builder: (context) {
              return IconButton(
                icon: const Icon(Icons.menu, color: Colors.white),
                onPressed: () => Scaffold.of(context).openEndDrawer(),
              );
            },
          ),
        ],
      ),
      body: Container(
        color: Colors.black,
        child: Column(
          children: [
            // Filtering UI with FilterChips.
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
                vertical: 8.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FilterChip(
                    label: Text(
                      'All',
                      style: TextStyle(
                        color: selectedSegment == 'all'
                            ? Colors.white
                            : Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                    selected: selectedSegment == 'all',
                    onSelected: (bool selected) {
                      setState(() {
                        selectedSegment = 'all';
                      });
                    },
                    selectedColor: Colors.blueAccent,
                    backgroundColor: Colors.grey[800],
                  ),
                  const SizedBox(width: 10),
                  FilterChip(
                    label: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.favorite,
                          size: 16,
                          color: selectedSegment == 'favorites'
                              ? Colors.white
                              : Colors.grey,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Favorites',
                          style: TextStyle(
                            color: selectedSegment == 'favorites'
                                ? Colors.white
                                : Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    selected: selectedSegment == 'favorites',
                    onSelected: (bool selected) {
                      setState(() {
                        selectedSegment = 'favorites';
                      });
                    },
                    selectedColor: Colors.blueAccent,
                    backgroundColor: Colors.grey[800],
                  ),
                ],
              ),
            ),
            // Display notes as either grid or list.
            Expanded(
              child: displayedNotes.isEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.add_box,
                      size: 60,
                      color: Colors.grey,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "No Notes Found",
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Click the Add button to add notes",
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              )
                  : _isGridMode
                  ? GridView.builder(
                gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  // Adjusted childAspectRatio for a compact, balanced grid cell.
                  childAspectRatio: 1.0,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                padding: const EdgeInsets.all(8),
                itemCount: displayedNotes.length,
                itemBuilder: (context, index) {
                  final note = displayedNotes[index];
                  final originalIndex = notes.indexOf(note);
                  return _buildGridNoteItem(note, originalIndex);
                },
              )
                  : ListView.builder(
                itemCount: displayedNotes.length,
                itemBuilder: (context, index) {
                  final note = displayedNotes[index];
                  final originalIndex = notes.indexOf(note);
                  return _buildListNoteItem(note, originalIndex);
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addNote,
        tooltip: "Add Note",
        label: const Text("Add Note"),
        icon: const Icon(Icons.add),
        backgroundColor: Colors.blueAccent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      subtitle: subtitle != null
          ? Text(
        subtitle,
        style: const TextStyle(color: Colors.grey, fontSize: 12),
      )
          : null,
      trailing: const Icon(
        Icons.arrow_forward_ios,
        color: Colors.white38,
        size: 16,
      ),
      onTap: onTap,
    );
  }

  void _showComingSoonDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Coming Soon!"),
        content: const Text("This feature is coming soon. Stay tuned!"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Okay"),
          ),
        ],
      ),
    );
  }
}
