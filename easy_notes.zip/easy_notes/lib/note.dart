import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class Note {
  String title;
  String content;
  bool archived;
  bool isFavorite;
  bool isPinned;
  DateTime lastModified;
  DateTime timestamp;

  // New formatting properties
  bool isTitleBold;
  bool isTitleItalic;
  bool isContentBold;
  bool isContentItalic;
  bool isContentUnderline;

  Note({
    required this.title,
    required this.content,
    this.archived = false,
    this.isFavorite = false,
    this.isPinned = false,
    DateTime? lastModified,
    DateTime? timestamp,
    // Default formatting is off
    this.isTitleBold = false,
    this.isTitleItalic = false,
    this.isContentBold = false,
    this.isContentItalic = false,
    this.isContentUnderline = false,
  })  : lastModified = lastModified ?? DateTime.now(),
        timestamp = timestamp ?? DateTime.now();

  // Convert a Note to a Map
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'content': content,
      'archived': archived,
      'isFavorite': isFavorite,
      'isPinned': isPinned,
      'lastModified': lastModified.toIso8601String(),
      'timestamp': timestamp.toIso8601String(),
      // Formatting properties
      'isTitleBold': isTitleBold,
      'isTitleItalic': isTitleItalic,
      'isContentBold': isContentBold,
      'isContentItalic': isContentItalic,
      'isContentUnderline': isContentUnderline,
    };
  }

  // Create a Note from a Map
  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      title: map['title'] ?? '',
      content: map['content'] ?? '',
      archived: map['archived'] ?? false,
      isFavorite: map['isFavorite'] ?? false,
      isPinned: map['isPinned'] ?? false,
      lastModified: DateTime.parse(
        map['lastModified'] ?? DateTime.now().toIso8601String(),
      ),
      timestamp: DateTime.parse(
        map['timestamp'] ?? DateTime.now().toIso8601String(),
      ),
      // Read formatting values from map (default to false)
      isTitleBold: map['isTitleBold'] ?? false,
      isTitleItalic: map['isTitleItalic'] ?? false,
      isContentBold: map['isContentBold'] ?? false,
      isContentItalic: map['isContentItalic'] ?? false,
      isContentUnderline: map['isContentUnderline'] ?? false,
    );
  }

  // Convert a Note to a JSON string
  String toJson() {
    return jsonEncode(toMap());
  }

  // Create a Note from a JSON string
  factory Note.fromJson(String jsonString) {
    final Map<String, dynamic> map = jsonDecode(jsonString);
    return Note.fromMap(map);
  }

  // Update note fields and mark it as modified
  void update({
    String? newTitle,
    String? newContent,
    bool? isArchived,
    bool? favoriteStatus,
    bool? pinnedStatus,
    // New formatting parameters for update
    bool? titleBold,
    bool? titleItalic,
    bool? contentBold,
    bool? contentItalic,
    bool? contentUnderline,
  }) {
    title = newTitle ?? title;
    content = newContent ?? content;
    archived = isArchived ?? archived;
    isFavorite = favoriteStatus ?? isFavorite;
    isPinned = pinnedStatus ?? isPinned;
    // Update formatting if provided
    isTitleBold = titleBold ?? isTitleBold;
    isTitleItalic = titleItalic ?? isTitleItalic;
    isContentBold = contentBold ?? isContentBold;
    isContentItalic = contentItalic ?? isContentItalic;
    isContentUnderline = contentUnderline ?? isContentUnderline;
    lastModified = DateTime.now();
  }
}

// Load notes from SharedPreferences
Future<List<Note>> loadNotesFromPrefs() async {
  final prefs = await SharedPreferences.getInstance();
  final String? notesString = prefs.getString('notes');
  if (notesString != null) {
    final List<dynamic> decodedList = jsonDecode(notesString);
    print("Loaded notes: $decodedList");
    return decodedList.map((noteMap) => Note.fromMap(noteMap)).toList();
  }
  print("No notes found in SharedPreferences.");
  return [];
}

// Save notes to SharedPreferences
Future<void> saveNotesToPrefs(List<Note> notes) async {
  final prefs = await SharedPreferences.getInstance();
  final List<Map<String, dynamic>> notesMap =
  notes.map((note) => note.toMap()).toList();
  await prefs.setString('notes', jsonEncode(notesMap));
  print("Notes saved to SharedPreferences.");
}
