import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'note.dart';

class TrashScreen extends StatefulWidget {
  const TrashScreen({Key? key}) : super(key: key);

  @override
  _TrashScreenState createState() => _TrashScreenState();
}

class _TrashScreenState extends State<TrashScreen> {
  List<Note> trashNotes = [];
  final int retentionDays = 7; // Notes in trash will be permanently deleted after 7 days

  @override
  void initState() {
    super.initState();
    _loadTrashNotes();
  }

  Future<void> _loadTrashNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final trashData = prefs.getStringList('trashNotes') ?? [];
    List<Note> loadedNotes = trashData
        .map((noteData) {
      try {
        return Note.fromJson(noteData);
      } catch (e) {
        debugPrint('Error decoding note: $e');
        return null;
      }
    })
        .whereType<Note>()
        .toList();

    // Filter out notes older than retentionDays (auto-delete)
    List<Note> validNotes = [];
    for (var note in loadedNotes) {
      if (DateTime.now().difference(note.lastModified).inDays < retentionDays) {
        validNotes.add(note);
      }
    }

    // Update SharedPreferences if some notes were auto-deleted
    if (validNotes.length != loadedNotes.length) {
      final newTrashData = validNotes.map((note) => note.toJson()).toList();
      await prefs.setStringList('trashNotes', newTrashData);
    }

    setState(() {
      trashNotes = validNotes;
    });
  }

  Future<void> _restoreNote(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    // Add note back to main notes.
    final notesData = prefs.getStringList('notes') ?? [];
    notesData.add(note.toJson());
    await prefs.setStringList('notes', notesData);

    // Remove note from trash.
    final trashData = prefs.getStringList('trashNotes') ?? [];
    trashData.remove(note.toJson());
    await prefs.setStringList('trashNotes', trashData);

    setState(() {
      trashNotes.remove(note);
    });

    HapticFeedback.mediumImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Note restored'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            // Optional: Implement undo functionality here.
          },
        ),
      ),
    );
  }

  Future<void> _deleteNote(Note note) async {
    final prefs = await SharedPreferences.getInstance();
    final trashData = prefs.getStringList('trashNotes') ?? [];
    trashData.remove(note.toJson());
    await prefs.setStringList('trashNotes', trashData);

    setState(() {
      trashNotes.remove(note);
    });

    HapticFeedback.mediumImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Note permanently deleted'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            // Optional: Implement undo functionality here.
          },
        ),
      ),
    );
  }

  // Format the date in a user-friendly manner
  String formatDateTime(DateTime dateTime) {
    return DateFormat('MM/dd/yyyy hh:mm a').format(dateTime);
  }

  // Calculate remaining days before auto-deletion
  String daysLeftText(DateTime lastModified) {
    int daysPassed = DateTime.now().difference(lastModified).inDays;
    int daysLeft = retentionDays - daysPassed;
    if (daysLeft > 0) {
      return "Expires in $daysLeft day${daysLeft > 1 ? 's' : ''}";
    }
    return "Expired";
  }

  Future<bool?> _confirmRestore(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Restore Note',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to restore this note?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.white70),
            ),
            onPressed: () => Navigator.of(context).pop(false),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text(
              'Restore',
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () => Navigator.of(context).pop(true),
          ),
        ],
      ),
    );
  }

  Future<bool?> _confirmPermanentDelete(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Delete Permanently',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to permanently delete this note? This action cannot be undone.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.white70),
            ),
            onPressed: () => Navigator.of(context).pop(false),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () => Navigator.of(context).pop(true),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trash'), backgroundColor: Colors.black),
      backgroundColor: Colors.black,
      body: trashNotes.isEmpty
          ? Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedOpacity(
              opacity: 1.0,
              duration: const Duration(milliseconds: 500),
              child: Icon(
                Icons.delete_outline,
                size: 100,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Trash is empty',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Your deleted notes will appear here.',
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
          ],
        ),
      )
          : Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Notes in trash will be permanently deleted after $retentionDays days.',
              style: TextStyle(color: Colors.white70),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: trashNotes.length,
              padding: const EdgeInsets.all(8.0),
              itemBuilder: (context, index) {
                final note = trashNotes[index];
                // Truncate title to 25 characters and content to 58 characters.
                final truncatedTitle = note.title.length > 25
                    ? note.title.substring(0, 25) + "..."
                    : note.title;
                final truncatedContent = note.content.length > 58
                    ? note.content.substring(0, 58) + "..."
                    : note.content;
                return Card(
                  color: Colors.grey[850],
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          truncatedTitle,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          truncatedContent,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white70,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Last Modified: ${formatDateTime(note.lastModified)}",
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          daysLeftText(note.lastModified),
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.orangeAccent,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              icon: const Icon(Icons.restore, size: 18),
                              label: const Text('Restore'),
                              onPressed: () async {
                                final confirm = await _confirmRestore(context);
                                if (confirm == true) {
                                  _restoreNote(note);
                                }
                              },
                            ),
                            const SizedBox(width: 10),
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              icon: const Icon(Icons.delete_forever, size: 18),
                              label: const Text('Delete'),
                              onPressed: () async {
                                final confirm = await _confirmPermanentDelete(context);
                                if (confirm == true) {
                                  _deleteNote(note);
                                }
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
