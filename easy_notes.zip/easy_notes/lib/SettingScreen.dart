import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool isLightMode = false;
  bool isPasscodeSet = false;
  bool _isLoading = false; // to indicate asynchronous operations

  @override
  void initState() {
    super.initState();
    _loadThemePreference();
    _loadPasscodeStatus();
  }

  Future<void> _loadThemePreference() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        isLightMode = prefs.getBool('isLightMode') ?? false;
      });
    } catch (error) {
      _showErrorSnackbar('Failed to load theme preference: $error');
    }
  }

  Future<void> _loadPasscodeStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedPasscode = prefs.getString('appPassword');
      setState(() {
        isPasscodeSet = storedPasscode != null && storedPasscode.isNotEmpty;
      });
    } catch (error) {
      _showErrorSnackbar('Failed to load passcode status: $error');
    }
  }

  void _toggleTheme(bool value) {
    setState(() {
      isLightMode = value;
    });
    _showComingSoonDialog('Light Mode');
  }

  void _showComingSoonDialog(String feature) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text(feature),
            content: const Text('Coming Soon!'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// Opens a dialog with a form to set a new passcode including confirmation.
  Future<void> _setPassword() async {
    final _formKey = GlobalKey<FormState>();
    String password = '';
    String confirmPassword = '';
    bool obscurePassword = true;
    bool obscureConfirmPassword = true;

    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false, // force the user to choose an action
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Set Password'),
              content: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      autofocus: true,
                      obscureText: obscurePassword,
                      decoration: InputDecoration(
                        hintText: 'Enter a password',
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(
                            obscurePassword
                                ? Icons.visibility_off
                                : Icons.visibility,
                          ),
                          onPressed: () {
                            setState(() {
                              obscurePassword = !obscurePassword;
                            });
                          },
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Password cannot be empty';
                        }
                        if (value.length < 4) {
                          return 'Password must be at least 4 characters';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        password = value;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      obscureText: obscureConfirmPassword,
                      decoration: InputDecoration(
                        hintText: 'Confirm password',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          icon: Icon(
                            obscureConfirmPassword
                                ? Icons.visibility_off
                                : Icons.visibility,
                          ),
                          onPressed: () {
                            setState(() {
                              obscureConfirmPassword = !obscureConfirmPassword;
                            });
                          },
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please confirm your password';
                        }
                        if (value != password) {
                          return 'Passwords do not match';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        confirmPassword = value;
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Navigator.pop(context, password);
                    }
                  },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result != null && result.isNotEmpty) {
      try {
        setState(() {
          _isLoading = true;
        });
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('appPassword', result);
        setState(() {
          isPasscodeSet = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Password Set Successfully!')),
        );
      } catch (error) {
        _showErrorSnackbar('Failed to set password: $error');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  /// Opens a confirmation dialog and then disables the passcode.
  Future<void> _disablePassword() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final storedPasscode = prefs.getString('appPassword');
      if (storedPasscode == null || storedPasscode.isEmpty) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('No passcode is set.')));
        return;
      }

      final confirmed = await showDialog<bool>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Disable Passcode'),
              content: const Text(
                'Are you sure you want to disable the passcode?',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Disable'),
                ),
              ],
            ),
      );

      if (confirmed == true) {
        setState(() {
          _isLoading = true;
        });
        await prefs.remove('appPassword');
        setState(() {
          isPasscodeSet = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Passcode disabled successfully!')),
        );
      }
    } catch (error) {
      _showErrorSnackbar('Failed to disable passcode: $error');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showCredits() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Credits'),
            content: const Text(
              'Credits\n\n'
              'Developer: Malek Mohamed Samir\n'
              'Design & Development: Malek Mohamed Samir\n'
              'Libraries Used: Flutter, Dart, Shared Preferences\n'
              'Copyright: © 2025 Malek Mohamed Samir. All rights reserved.\n\n'
              'Special thanks to all users.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  Future<void> _showFeedbackDialog() async {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Feedback'),
            content: const Text('Feedback - Coming Soon!'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(title: const Text('Settings')),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListView(
              children: [
                Card(
                  elevation: 2,
                  child: Column(
                    children: [
                      SwitchListTile(
                        title: const Text('Light Mode'),
                        value: isLightMode,
                        onChanged: _toggleTheme,
                      ),
                      ListTile(
                        leading: const Icon(Icons.notifications),
                        title: const Text('Notifications'),
                        onTap: () => _showComingSoonDialog('Notifications'),
                      ),
                      ListTile(
                        leading: const Icon(Icons.lock),
                        title: Row(
                          children: [
                            Text(
                              isPasscodeSet
                                  ? 'Remove App Password'
                                  : 'Set App Password',
                            ),
                            const Spacer(),
                            if (!isPasscodeSet)
                              const Text(
                                'Available now!',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                          ],
                        ),
                        onTap: isPasscodeSet ? _disablePassword : _setPassword,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Card(
                  elevation: 2,
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.credit_score),
                        title: const Text('Credits'),
                        onTap: _showCredits,
                      ),
                      ListTile(
                        leading: const Icon(Icons.feedback),
                        title: const Text('Feedback'),
                        onTap: _showFeedbackDialog,
                      ),
                      const ListTile(
                        leading: Icon(Icons.info),
                        title: Text('App Info'),
                        subtitle: Text('Version 1.0.0'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_isLoading)
          Container(
            color: Colors.black.withOpacity(0.3),
            child: const Center(child: CircularProgressIndicator()),
          ),
      ],
    );
  }
}
