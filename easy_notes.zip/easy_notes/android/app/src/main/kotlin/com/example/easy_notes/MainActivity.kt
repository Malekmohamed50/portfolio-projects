package com.example.easy_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
